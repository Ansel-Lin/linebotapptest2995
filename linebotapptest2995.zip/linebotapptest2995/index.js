module.exports = require('./lib/linebot');

var linebot = require('linebot');
var express = require('linebotapptest2995');

var bot = linebot({
  channelId: 1619847405,
  channelSecret: c5fec465f052c7926e29047a45a27982,
  channelAccessToken: uRXfGW00ZeFZltwmTa40EkEGuN0nFWFK7so3uDuxcrwM4OT+aBKBHnRTtwOu69ttEMefprom3w0U+7TMpG92s6AtS5UF4CEEUEqEEHeYwlWdm4y5Jcx1VKnAgBm9O+L5xySj3ff8Bmi48aa+MGhUqQdB04t89/1O/w1cDnyilFU=
});

bot.on('message', function(event) {
  console.log(event); //把收到訊息的 event 印出來看看
});

const app = express();
const linebotParser = bot.parser();
app.post('/', linebotParser);

//因為 express 預設走 port 3000，而 heroku 上預設卻不是，要透過下列程式轉換
var server = app.listen(process.env.PORT || 8080, function() {
  var port = server.address().port;
  console.log("App now running on port", port);
});
